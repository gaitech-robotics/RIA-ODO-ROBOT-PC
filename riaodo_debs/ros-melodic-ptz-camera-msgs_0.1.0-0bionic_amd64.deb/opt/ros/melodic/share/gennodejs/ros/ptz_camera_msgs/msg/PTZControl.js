// Auto-generated. Do not edit!

// (in-package ptz_camera_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class PTZControl {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.action = null;
      this.speed = null;
      this.stop = null;
      this.home = null;
    }
    else {
      if (initObj.hasOwnProperty('action')) {
        this.action = initObj.action
      }
      else {
        this.action = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('speed')) {
        this.speed = initObj.speed
      }
      else {
        this.speed = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('stop')) {
        this.stop = initObj.stop
      }
      else {
        this.stop = new std_msgs.msg.Bool();
      }
      if (initObj.hasOwnProperty('home')) {
        this.home = initObj.home
      }
      else {
        this.home = new std_msgs.msg.Bool();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PTZControl
    // Serialize message field [action]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.action, buffer, bufferOffset);
    // Serialize message field [speed]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.speed, buffer, bufferOffset);
    // Serialize message field [stop]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.stop, buffer, bufferOffset);
    // Serialize message field [home]
    bufferOffset = std_msgs.msg.Bool.serialize(obj.home, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PTZControl
    let len;
    let data = new PTZControl(null);
    // Deserialize message field [action]
    data.action = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [speed]
    data.speed = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [stop]
    data.stop = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    // Deserialize message field [home]
    data.home = std_msgs.msg.Bool.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 10;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ptz_camera_msgs/PTZControl';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bdb67c577a5aea22fc287de85819eac6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # #########################################
    # stop value can be any of these
    #  ZOOM_IN         0    
    #  ZOOM_OUT        1    
    #  FOCUS_NEAR      2   
    #  FOCUS_FAR       3  
    #  IRIS_OPEN       4  
    #  IRIS_CLOSE      5   
    #  TILT_UP         6     
    #  TILT_DOWN       7     
    #  PAN_LEFT        8    
    #  PAN_RIGHT       9     
    #  UP_LEFT         10     
    #  UP_RIGHT        11    
    #  DOWN_LEFT       12     
    #  DOWN_RIGHT      13    
    #  PAN_AUTO        14     
    # #########################################
    std_msgs/Int32 action
    
    # #########################################
    # speed value. Valid between 1 - 7    
    # #########################################
    std_msgs/Int32 speed
    
    # #########################################
    std_msgs/Bool stop
    
    # #########################################
    std_msgs/Bool home
    ================================================================================
    MSG: std_msgs/Int32
    int32 data
    ================================================================================
    MSG: std_msgs/Bool
    bool data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PTZControl(null);
    if (msg.action !== undefined) {
      resolved.action = std_msgs.msg.Int32.Resolve(msg.action)
    }
    else {
      resolved.action = new std_msgs.msg.Int32()
    }

    if (msg.speed !== undefined) {
      resolved.speed = std_msgs.msg.Int32.Resolve(msg.speed)
    }
    else {
      resolved.speed = new std_msgs.msg.Int32()
    }

    if (msg.stop !== undefined) {
      resolved.stop = std_msgs.msg.Bool.Resolve(msg.stop)
    }
    else {
      resolved.stop = new std_msgs.msg.Bool()
    }

    if (msg.home !== undefined) {
      resolved.home = std_msgs.msg.Bool.Resolve(msg.home)
    }
    else {
      resolved.home = new std_msgs.msg.Bool()
    }

    return resolved;
    }
};

module.exports = PTZControl;
