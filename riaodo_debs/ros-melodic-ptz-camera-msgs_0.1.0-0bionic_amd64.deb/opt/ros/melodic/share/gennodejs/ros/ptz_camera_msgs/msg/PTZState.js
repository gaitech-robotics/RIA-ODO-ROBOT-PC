// Auto-generated. Do not edit!

// (in-package ptz_camera_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class PTZState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.camera = null;
      this.pan = null;
      this.tilt = null;
      this.zoom = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('camera')) {
        this.camera = initObj.camera
      }
      else {
        this.camera = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('pan')) {
        this.pan = initObj.pan
      }
      else {
        this.pan = new std_msgs.msg.Float32();
      }
      if (initObj.hasOwnProperty('tilt')) {
        this.tilt = initObj.tilt
      }
      else {
        this.tilt = new std_msgs.msg.Float32();
      }
      if (initObj.hasOwnProperty('zoom')) {
        this.zoom = initObj.zoom
      }
      else {
        this.zoom = new std_msgs.msg.Float32();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PTZState
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [camera]
    bufferOffset = std_msgs.msg.String.serialize(obj.camera, buffer, bufferOffset);
    // Serialize message field [pan]
    bufferOffset = std_msgs.msg.Float32.serialize(obj.pan, buffer, bufferOffset);
    // Serialize message field [tilt]
    bufferOffset = std_msgs.msg.Float32.serialize(obj.tilt, buffer, bufferOffset);
    // Serialize message field [zoom]
    bufferOffset = std_msgs.msg.Float32.serialize(obj.zoom, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PTZState
    let len;
    let data = new PTZState(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [camera]
    data.camera = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [pan]
    data.pan = std_msgs.msg.Float32.deserialize(buffer, bufferOffset);
    // Deserialize message field [tilt]
    data.tilt = std_msgs.msg.Float32.deserialize(buffer, bufferOffset);
    // Deserialize message field [zoom]
    data.zoom = std_msgs.msg.Float32.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += std_msgs.msg.String.getMessageSize(object.camera);
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ptz_camera_msgs/PTZState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'e6b9aca56e629c2bf250755d80563ff4';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # header
    std_msgs/Header header  
    # camera name
    std_msgs/String camera
    # pan tilt angle and zoom value
    std_msgs/Float32 pan
    std_msgs/Float32 tilt
    std_msgs/Float32 zoom
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: std_msgs/String
    string data
    
    ================================================================================
    MSG: std_msgs/Float32
    float32 data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PTZState(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.camera !== undefined) {
      resolved.camera = std_msgs.msg.String.Resolve(msg.camera)
    }
    else {
      resolved.camera = new std_msgs.msg.String()
    }

    if (msg.pan !== undefined) {
      resolved.pan = std_msgs.msg.Float32.Resolve(msg.pan)
    }
    else {
      resolved.pan = new std_msgs.msg.Float32()
    }

    if (msg.tilt !== undefined) {
      resolved.tilt = std_msgs.msg.Float32.Resolve(msg.tilt)
    }
    else {
      resolved.tilt = new std_msgs.msg.Float32()
    }

    if (msg.zoom !== undefined) {
      resolved.zoom = std_msgs.msg.Float32.Resolve(msg.zoom)
    }
    else {
      resolved.zoom = new std_msgs.msg.Float32()
    }

    return resolved;
    }
};

module.exports = PTZState;
