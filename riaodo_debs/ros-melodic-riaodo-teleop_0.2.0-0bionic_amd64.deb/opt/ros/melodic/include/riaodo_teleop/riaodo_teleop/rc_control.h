#ifndef _RC_CONTROL_H_
#define _RC_CONTROL_H_

#include <stdio.h>
#include <string.h>
#include <ros/ros.h>
#include <mavros_msgs/RCIn.h>
#include <geometry_msgs/Twist.h>

namespace riaodo_teleop
{
	class RC
	{
		public:
			RC(const ros::NodeHandle& n, const ros::NodeHandle& p);
			virtual ~RC() = default;
			ros::NodeHandle _nh, _pnh;
			ros::Subscriber rc_sub;
			ros::Publisher vel_pub;
			geometry_msgs::Twist vel;

		private:
			std::string _rc_topic,_cmd_vel_topic;
			bool _add_tolerance, _joy_enable;
			int _tolerance_value;
			double _linear_max,_angular_max;
			int _channels_num,_channels_max,_channels_min,_channels_mid;
			int _left_down2up,_left_left2right;
			int _right_down2up,_right_left2right;
			int _channels_min_tole[2], _channels_max_tole[2], _channels_mid_tole[2];
			float k_l,b_l,k_a,b_a;
			float k_l_tole,b_l_forw_tole,b_l_back_tole;
			float k_a_tole,b_a_left_tole,b_a_right_tole;
			int _count;
			void RCValueCB(const mavros_msgs::RCIn::ConstPtr& msg);
			
	};
}

#endif 
